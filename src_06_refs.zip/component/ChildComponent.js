import React, { Component } from 'react';

export class ChildComponent extends Component {
    constructor(){
        super();
        this.submit= this.submit.bind(this);//함수 생성
        //console.log("contructor", this.submit);
    }
    render() {
        return (
            <form onSubmit={this.submit}>
                아이디<input type="text" ref="userid"/>
                비밀번호<input type="text" ref="passwd"/>
                <button>로그인</button>
            </form>
        );
    }//end render()
    //
    submit(e){
        e.preventDefault();//return false지원안함
        console.log("submit", this);
        //input태그의 ref 값은 this.refs로 참조함
        const {userid, passwd}= this.refs;        
        console.log("submit(e)", userid.value,"\t" ,passwd.value);

    }
}

