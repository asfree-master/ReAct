import React, { Component } from 'react';
import './App.css';
import {ChildComponent} from './component/ChildComponent'

class App extends Component {
    render() {
        return (
            <div>
                <ChildComponent/>
            </div>
        );
    }
}

export default App;