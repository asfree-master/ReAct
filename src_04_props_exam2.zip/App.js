import React, { Component } from 'react';
import {PersonList} from './component/PersonList';
class App extends Component {
  persons=[
    {name:"홍길동", age:20},
    {name:"이순신", age:30},
    {name:"유관순", age:40},
  ];
  render() {
    return (
      <div>
        <h1>학생정보</h1>
        <table border="1">
          <thead>
            <tr>
              <th>번호</th>
              <th>이름</th>
              <th>나이</th>
            </tr>
          </thead>
          <PersonList xxx={this.persons} />
        </table>
      </div>
    );
  }
}

export default App;