import React, { Component } from 'react';

export class Person extends Component {
    person;
    render() {
        this.person= this.props.yyy;
        return (
          <tr>
              <td>{this.props.yyy2+1}</td>
              <td>{this.person.name}</td>
              <td>{this.person.age}</td>
          </tr>
        )
    }
}
