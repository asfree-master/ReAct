import React, { Component } from 'react';
import './App.css';
import Child from './child/Child'

class App extends Component {
    render() {
        return (
            <div>
             <Child/>
            </div>
        );
    }
}

export default App;