import React, { Component } from 'react';

class Child extends Component {
    render() {
        return (
            <div>
                <button onClick={this.handleEvent}>handleEvent</button><br></br>
                <button onClick={this.handleEvent2}>handleEvent2</button><br></br>
               <a href="http://www.daum.net" onClick={this.handleEvent3}>daum-eventPrevent</a><br></br>
               <button onClick={()=>this.a()}>this.a()</button><br></br>
               <button onClick={(e)=>this.b(e, 100)}>b(x,y)</button><br></br>
            </div>
        );
    }//end render
    a(){
        console.log("a=====================");
    }
    b(x,y){
        console.log("b=====", x, y);
    }
    handleEvent(){
        console.log("Ok=======");
    }
   handleEvent2(e){
        console.log("OK2====",e);
   }
   handleEvent3(e){
       console.log("eventPreventDefault()");
       e.preventDefault(); //return false 지원안됨
   }
    
}


export default Child;