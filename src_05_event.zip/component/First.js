import React, { Component } from 'react';
import {Second} from './Second'

export class First extends Component {
    render() {
        return (
            <div>

               {/* <Second id={this.props.id} pw={this.props.pw}/> */}
               {/* spread연산자 사용 */}
               <Second {...this.props}/>
            </div>
        );
    }
}

