import React, { Component } from 'react';
import {Third}from './Third'

export class Second extends Component {
    render() {
        return (
            <div>
                {/* <Third id={this.props.id} pw={this.props.pw}/> */}
                {/* spread연산자 사용 */}
                <Third {...this.props}/>
            </div>
        );
    }
}

