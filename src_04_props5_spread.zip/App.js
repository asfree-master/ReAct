import React, { Component } from 'react';
import './App.css';
import {First}from './component/First';

class App extends Component {
    render() {
        return (
            <div>
                <First id="userid" pw="1234"/>
            </div>
        );
    }
}

export default App;