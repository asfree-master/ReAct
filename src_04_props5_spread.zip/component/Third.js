import React, { Component } from 'react';

export class Third extends Component {
    render() {
        return (
            <div>
                {/* <p>{this.props.id}</p>
                <p>{this.props.pw}</p> */}
                {this.props.id}<br/>
                {this.props.pw}<br/>
            </div>
        );
    }
}

