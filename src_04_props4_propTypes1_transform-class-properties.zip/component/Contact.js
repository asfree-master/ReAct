import React, { Component } from 'react';
import PropTypes from 'prop-types';
export class Contact extends Component {
    static defaultProps={
        mesg:"유관순",
        mesg2:20
    }
    static propsTypes={
        mesg:PropTypes.string,
        mesg2:PropTypes.number
       // mesg2:PropTypes.number.isRequired
        
    }
    render() {
        let mesg=this.props.mesg;
        return (
            <div>
                <h1>{mesg}</h1>
                <h1>{this.props.mesg2}</h1>
            </div>
        );
    }
}//end class
//검증작업
// Contact.propTypes={
//     mesg:PropTypes.string,
//     mesg2:PropTypes.number.isRequired
//     // mesg2:PropTypes.number.isRequired
    
// }
//기본값설정
// Contact.defaultProps={
//     mesg:"유관순",
//     mesg2:20
// }

