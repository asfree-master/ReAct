import React, { Component } from 'react';

export class Contact extends Component {
    render() {
        return (          
                <h1>Contacts 홈페이지 </h1>           
        );
    }
}
export class Contact2 extends Component{
    info(){
        return <h1>Contact2 홈페이지 </h1>
    }
    render(){
        return(this.info());
    }
}