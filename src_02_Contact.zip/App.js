import React, { Component } from 'react';
import {Contact, Contact2} from './component/Contact';
class App extends Component {
  render() {
    return (
      <div>
        <Contact/>
        <Contact2/>
      </div>
    );
  }
}

export default App;