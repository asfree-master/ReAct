import React, { Component } from 'react';

export class ChildComponent extends Component {
    constructor(){
        super();
        this.submit= this.submit.bind(this);//함수 생성
        console.log("constructor");
        //console.log("constructor", this.submit);
    }
    //passwd 필요없음. this.passwd면 동적으로 추가됨
    render() {
        return (
            <form onSubmit={this.submit}>
                아이디<input type="text" ref="userid"/>
                {/* ref값 콜백함수로 지정가능 */}
                비밀번호<input type="text" ref={(x)=>{
                    console.log("x",x);
                    this.passwd=x;
                }}/>
                <button>로그인</button>
            </form>
        );
    }//end render()
    //
    submit(e){
        e.preventDefault();//return false지원안함
        console.log("submit", this.refs);
        console.log("this.passwd", this.passwd);
        //input태그의 ref 값은 this.refs로 참조함
        const {userid}=this.refs;
        userid.value="AAAAAAA";
        //userid.focus();
        console.log( userid.value,"\t" ,this.passwd.value);

    }
}

