import React, { Component } from 'react';
import './App.css';
import {Contact} from './component/Contact'
class App extends Component {

  render() {
    return (
      <div>
      {/* <Contact mesg="100" mesg2="10"/> */}
      {/* <Contact mesg="100" mesg2="10"/> type오류 */}
      <Contact mesg="100" mesg2={10}/>
      {/* <Contact mesg="100" mesg2={10}/>  number데이터 전달*/}
      <Contact/>
      </div>
    );
  }
}

export default App;