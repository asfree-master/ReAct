import React, { Component } from 'react';

export class Contact2 extends Component {
    render() {
        let {mesg,mesg2}=this.props;
        return (
            <div>
                <h1>Contact2 mesg:{mesg}</h1>
                <h1>Contact2 mesg2: {mesg2}</h1>
            </div>
        );
    }
}

