import React, { Component } from 'react';
export class Contact extends Component {
    render() {
        console.log(this);
        let mesg= this.props.mesg;
        let mesg2= this.props.mesg2;
        return (
            <div>
                <h1>Contact mesg:{mesg}</h1>
                <h1>Contact mesg2:{mesg2}</h1>
                <h1>Contact this.props.mesg{this.props.mesg}</h1>
                <h1>Contact this.mesg2{this.mesg2}</h1>
            </div>
        );
    }
}

