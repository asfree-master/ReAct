import React, { Component } from 'react';

export class Contact extends Component {
    constructor(){
        super();
        this.state={
            userid:"",
            passwd:""
        }
        this.handleEvent= this.handleEvent.bind(this);
    }//end constructor
    handleEvent(e){
      e.preventDefault();
      const {x, y} = this.refs;
      this.setState(
        {
          userid:x.value,
          passwd:y.value
        }
      )
    }
    render() {
        return (
            <div>
             <form onSubmit={this.handleEvent}>
               아이디:<input type="text" ref="x"/><br></br>
               패스워드:<input type='text' ref="y"/><br></br>
               <button>로그인</button>
             </form>
             아이디:{this.state.userid}<br></br>
             패스워드:{this.state.passwd}<br></br>
            </div>
        );
    }//end render
  
}

