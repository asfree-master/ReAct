import React, { Component } from 'react';
import './App.css';
import {ChildComponent} from './component/ChildComponent'

class App extends Component {
    render() {
        return (
            <div>
                <ChildComponent ref={(ref)=>{
                    console.log(ref);//ChildComponent
                    this.AppComponent= ref;//this.AppComponent에 ChildComponent설정
                }}/>
                <button onClick={e=>this.AppComponent.info()}>OK</button>
                {/* event를 전달하며 자식컴포넌트 함수 호출 */}
            </div>
        );
    }
}

export default App;