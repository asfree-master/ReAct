import React, { Component } from 'react';

export class ChildComponent extends Component {
 
    info(){
        console.log("ChildComponent info()");
    }
    render() {
        return (
            <div>
                <h1>컴포넌트 ref 실습</h1>
            </div>
        );
    }
}

