import React, { Component } from 'react';
import {Contact} from './component/Contact';
class App extends Component {
    ///////////////
    name="홍길동";
    age=20;
    phones=['010', '011'];
    my= function(){
        console.log("my함수");
    }
   

    //////////////
    render() {
        return (
            <div>
                {/* <Contact mesg="홍길동" mesg2="10"/> */}
                <Contact name={this.name} age={this.age} phones={this.phones} 
                my={this.my} 
                />
            </div>
        );
    }
}

export default App;