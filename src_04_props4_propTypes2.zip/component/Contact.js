import React, { Component } from 'react';
import PropTypes from 'prop-types';
export class Contact extends Component {   
    render() {
        let name=this.props.name;
        let phones= this.props.phones;
        console.log("phones>>",phones);
        return (
            <div>
                <h1>{name}</h1>               
                <h1>{this.props.age}</h1>
                <h1>{this.props.phones}</h1>
                <h1>{this.props.phones[0]}</h1>
                <h1>{this.props.phones[1]}</h1>
                <h1>{this.props.my()}</h1>
            </div>
        );
    }
}//end class
//검증작업
Contact.propTypes={
    name:PropTypes.string,
    age:PropTypes.number,
    phones:PropTypes.array,
    my:PropTypes.func 
}
//기본값설정
Contact.defaultProps={
    name:"유관순",
    age:20
}

