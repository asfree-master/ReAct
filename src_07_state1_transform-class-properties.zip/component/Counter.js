import React, { Component } from 'react';

export class Counter extends Component{

    // 아래 생성자와 동일한 기능
    state={
        num:0
    }
    // constructor(){
    //     super();
    //     this.state={
    //         num:0
    //     };
    // }
     //arrow 함수 사용하면 bind 필요없다.
     handleClick=(e)=>{
       this.setState({
           num: this.state.num + 1
       });
     }
  
      render(){
          return (
          <div>
           <h2>{this.state.num}</h2>
              <button onClick={this.handleClick}>press me</button>
          </div>
          );
      }
  
  }