import React, { Component } from 'react';

export class Contact extends Component {
    constructor(){
        super();
        this.state={
            contactData:[
                {name:'Allen', phone:'000-000-0001'},
                {name:'Bob', phone:'000-000-0002'},
                {name:'Charli', phone:'000-000-0003'},
                {name:'David', phone:'000-000-0004'},
            ],
        username:''
        };//end state배열변경시 setState()를 사용하여 변경해야함
        //binding
        this.handle=this.handle.bind(this);
        this.handleChange=this.handleChange.bind(this);
    }//end constructor
    render() {
        return (
            <div>
                {
                    this.state.contactData.map(function(row, idx){
                        return <div key={idx}>{row.name} &nbsp;&nbsp;{row.phone}</div>;
                    })
                }
                이름:<input type="text" name="username" id="kkk"
                value={this.state.username} onChange={this.handleChange}></input><br></br>
                <button onClick={this.handle}>add</button>
            </div>
        );
    }//end render
    handleChange(e){
        this.setState(
            {
                username: e.target.value
            }
        );
    }//end handle
    handle(){
        //let v= document.getElementById("kkk").value;
        console.log("handle");
        let xxx= this.state.contactData;
        xxx.push({name:this.state.username, phone:"010-000-1111"});
        this.setState(
            {
                contactData:xxx //상태데이터 변경
            }
        );
    }//end handle
}

