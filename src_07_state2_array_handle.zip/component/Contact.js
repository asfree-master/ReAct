import React, { Component } from 'react';

export class Contact extends Component {
    constructor(){
        super();
        this.state={
            contactData:[
                {name:'Allen', phone:'000-000-0001'},
                {name:'Bob', phone:'000-000-0002'},
                {name:'Charli', phone:'000-000-0003'},
                {name:'David', phone:'000-000-0004'},
            ]
        };//배열변경시 setState()를 사용하여 변경해야함
        //binding
        this.handle=this.handle.bind(this);
    }
    render() {
        return (
            <div>
                {
                    this.state.contactData.map(function(row, idx){
                        return <div key={idx}>{row.name} &nbsp;&nbsp;{row.phone}</div>;
                    })
                }
                <button onClick={this.handle}>add</button>
            </div>
        );
    }//end render
    handle(){
        console.log("handle");
        let xxx= this.state.contactData;//주의 
        xxx.push({name:'Chaily', phone:'000-000-0005'});
        this.setState({ //push후 this.setState를 사용하여 상태값 변경함
            contactData:xxx
        });
    }
}

