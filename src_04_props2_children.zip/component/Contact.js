import React, { Component } from 'react';

export class Contact extends Component {
    render() {
    console.log(this);
    let mesg=this.props.mesg;
    let body= this.props.children; //body부분을 받음
    console.log(">>>",body);
    console.log(body[0], body[1].props.children);
        return (
            <div>
                <h1>mesg:{mesg}</h1>
                <h1>this.props.mesg2: {this.props.mesg2}</h1>
                <h1>{body}</h1>
            </div>
        );
    }
}

