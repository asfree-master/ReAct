import React, { Component } from 'react';
import  {Contact} from './component/Contact'

class App extends Component {
    render() {
        return (
            <div>
                <Contact/>
            </div>
        );
    }
}

export default App;