import React, { Component } from 'react';

export class Contact extends Component {
    constructor(){
        super();
        this.state={
            userid:"",
            passwd:""
        }//end state배열변경시 setState()를 사용하여 변경해야함
        //binding
        this.handleEvent=this.handleEvent.bind(this);
        this.handleChange=this.handleChange.bind(this);
    }//end constructor
    handleChange(e){
      console.log(">>", e.target.name, e.target.value);
      let nextState={};
      nextState[e.target.name]= e.target.value;
      console.log("handleChange(e)======", nextState);
      this.setState(nextState);
    }//end handle
    handleEvent(e){
      e.preventDefault();
    //   const{x,y}= this.refs;
    //   let nextState={};
    //   nextState[e.target.name]= e.target.value;
    //   this.setState(nextState);
    }//end handle
    render() {
        return (
            <div>
              <form onSubmit={this.handleEvent}>
                  아이디<input type="text" value={this.state.userid} name="userid" 
                  onChange={this.handleChange}/><br></br>
                  아이디<input type="text" value={this.state.passwd} name="passwd" 
                  onChange={this.handleChange}/><br></br>
              </form>
              아이디: {this.state.userid}<br></br>
              패스워드: {this.state.passwd}<br></br>
            </div>
        );
    }//end render
  
}

