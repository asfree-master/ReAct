import React, { Component } from 'react';

export class Contact extends Component {
    static defaultProps={
        mesg:"유관순",
        mesg2:"20"
    }
    render() {
        let {mesg:a, mesg2:b}= this.props;
        return (
            <div>
                <h1>{a}</h1>
                <h1>{b}</h1>
            </div>
        );
    }
}
//기본값 설정 class외부에서 선언
//  Contact.defaultProps={
//         mesg:"유관순",
//         mesg2:"20"
// }
