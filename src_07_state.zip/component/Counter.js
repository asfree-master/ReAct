import React, { Component } from 'react';

export class Counter extends Component {
    constructor(){
        super();// 주의
        this.state={//생성자에서 초기회
            xyz:0,
            number:100
        };
        this.handleClick= this.handleClick.bind(this);//setState를 사용하기 위한 bind
    }//end constructor

    handleClick(){
        this.setState(
            {
                xyz:this.state.xyz+1 //state값의 변경 
            }
        );
    }
    render() {
        return (
            <div>
                <h2>{this.state.xyz}</h2>
                <p>{this.state.number}</p>
                <button onClick={this.handleClick}>press me</button>
            </div>
        );
    }
}

