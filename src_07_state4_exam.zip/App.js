import React, { Component } from 'react';
import {Member} from './component/Member'

class App extends Component {
    render() {
        return (
            <div>
                <Member/>
            </div>
        );
    }
}

export default App;