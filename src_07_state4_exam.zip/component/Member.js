import React, { Component } from 'react';
import {MemberList} from './MemberList';
export class Member extends Component {
    constructor(){
        super();
        this.state={
            memberData:[],
            username:"",
            age:"",
            address:""
        };
        //binding
        this.handleChange=this.handleChange.bind(this);
        this.addMember= this.addMember.bind(this);
    }
    render() {
        return (
            <div>
                이름<input type="text" name="username" valeu={this.state.username}
                onChange={this.handleChange}/><br></br>
                나이<input type="text" name="age" valeu={this.state.age}
                onChange={this.handleChange}/><br></br>
                주소<input type="text" name="address" valeu={this.state.address}
                onChange={this.handleChange}/><br></br>
                <button onClick={this.addMember}>저장</button>
                <button onClick={this.xyz.bind(this,"홍길동")}>xyz 함수 호출 </button>
                <MemberList memberData={this.state.memberData} />
                                {/* 데이터전송 */}
            </div>
        );
    }//end render
    //input 태그생태 변경
    handleChange(e){
        let nextState={};
        nextState[e.target.name]=e.target.value;
        this.setState(nextState);
    }
    //저장
    addMember(e){
        let xxx= this.state.memberData;
        xxx.push({username:this.state.username, age:this.state.age, address:this.state.address});
        this.setState(
            {
                memberData:xxx
            }
        );
    }//end handleChange
    xyz(e){
        console.log("param====", e);
    }
}

