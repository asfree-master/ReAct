import React, { Component } from 'react';

export class ChildComponent extends Component {
    constructor(){
        super();
        this.state={ //상태값 저장하기 위한 생성자에서 초기화 this.state={key:value}
            colorName:'White'
        }
    } 
    info(x){
        console.log("ChildComponent info()",x);
        this.setState({//상태값 변경을 위해서는 this.setState함수에서 상태값 변경
            colorName:x//상태값 변경 this.state.colorName=x 안됨
        });
    }
    render() {
        return (
            <div>
                <h1 style={{background:this.state.colorName}}>컴포넌트 ref 실습</h1>
                {/* {this.state.key}로 사용 */}
            </div>
        );
    }
}

