import React, { Component } from 'react';
import Contact from "./component/Contact"; //export default 
import {Contact2, Contact21, Contact3, Contact4} from './component/Contact';
 import {Contact5,Contact6,Contact7,Contact8} from './component/Contact'
class App extends Component {
  render() {
    var xxx= <Contact8/>; 
    // 외부변수에 component를 저장해서 사용
    return (
      <div>
        <Contact/>   
        <Contact2/>  
        <Contact21/>
        <Contact3 />
        <Contact4/>
        <Contact5/>
        <Contact6/>
        <Contact7/>
       {xxx} 
       {/* 외부변수에 저장된 class사용 */}
      </div>
    );
  }
}
export default App;