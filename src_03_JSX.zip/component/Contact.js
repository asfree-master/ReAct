import React, { Component } from 'react';
import './Contact.css';
/* export와 export default의 차이점
    1. export default는 모듈에서 반드시 하나만 사용가능 
    import 시 
    import Concat from './component/Concat';
    2. export는 모듈에서 여러번 사용가능 
    import 시 
    imprt {Concat} from './component/Concat';
*/
//1. jsx에서 변수값 사용시 {} 이용하고 반드시 root 태그가 존재야하며 "" 사용안됨
 export default class Contact extends Component {
    render() {
        let mesg="world";
        return (
            <h1>{mesg}&nbsp; {100}:{"hello"}</h1>
        );
    }
}

//2.JSX에서 자바스크립트사용시 {}이용
export class Contact2 extends Component{
    render(){
        let myArr=['A','B', 'C']
        return(
        <h1>
            {//자바스크립트 사용을 하기 위해 반드시 {}사용
                myArr.map(function(row, idx){
                    console.log(row, idx);
                return <li key={idx}>{row}</li>;
                })
             }
        </h1>
        )
    }
}
/////////////자바스크립트 render()메소드 밖에 있어서 다양한 작업 가능 ///
var myArr=["A", "B", "C"];
function my() {
   return myArr.map(function (row, idx) {
        console.log(row, idx);
        return <li key={idx}>{row}</li>;
    })    
}
//////////////////////////////////////////////////////
export class Contact21 extends Component{
    render(){
        return(
            <ul>
                {//자바스크립트 사용시 반드시 {} 사용
                my()
                }
            </ul>
        );
    }
}
////////////////////////////////////////////////////
// 3.JSX에서 spread 연산자 사용 예
export class Contact3 extends Component{
    render(){
        var attr={
            href:"http://www.daum.net",
            target:"_blank"
        };
     return(<a href={attr.href} target={attr.target}>daum가기</a>)
        // return(
        //     <a {...attr}>daum:{attr.href}</a>
        // )
    }
}
//4. JSX에서 multi node사용 예
export class Contact4 extends Component{
    render(){//render안에 선언
        var multi=[
            <span key="_1">Hello</span>,
            <span key="_2">world</span>
        ];
        return(
        <div>
            {multi}
        </div>
        );
    }
}
//5.JSX에서는 카멜표기법 필수
function myok() {
    console.log("myOk");
}
export class Contact5 extends Component{
    //메소드
    myok2(){
        console.log("this.myOk2");
    }//render 밖에 선언된 함수
    render(){
        return(
        <div>
            <button onClick={myok}>myok</button>
            <button onClick={this.myok2}>myOk2</button>
        </div>         
        )
    }
}
//6.JSX에서는 class속성 대신 className, for속성 대신 htmlFor형식으로 사용
export class Contact6 extends Component{
    render(){
        return(
            <div>
                <p className="xyz">Contact 6 hello</p>
                <label htmlFor="myInput">hello2</label>
                <input type="text" name="myInput"/>
            </div>
        )
    }
}
//7.JSX에서 style은 객체로 처리되어 인라인스타일지정을 권장함
//backgroundColor, fontSize, textAlign의 카멜표기법 사용//px만 생략가능
export class Contact7 extends Component{
    render(){
        var myStyle={fontSize:'50px', backgroundColor:'red'};
        return(
            <div>
                <p style={myStyle}>Happy</p>
                <p style={{fontSize:'20', backgroundColor:'yellow'}}>world</p>
            </div>
        )
    }
}
//8.JSX주석은 {/* */}형식으로 사용하고 반드시 container(root태그) 태그 내에서 사용해야 함
export class Contact8 extends Component{
    render(){
        var myStyle={fontSize:'50', backgroundColor:'yellow' };
        return(
            <div>
                {/* 이것은 JSX주석이며 root 태그 내에서 사용해야함 */}
                <p style={myStyle}>Happy</p>
                <p style={{fontSize:'10',backgroundColor:'red'}}>Happy</p>
            </div>
        )
    }
}