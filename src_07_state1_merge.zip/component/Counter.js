import React, { Component } from 'react';

export class Counter extends Component {
    constructor(){
        super();
        this.state={
            num:0
        };
        this.handleClick= this.handleClick.bind(this);
        //바인딩
    };
    handleClick(){
        this.setState(
            {//기존 this.state에 병합(merge) 형태로 설정됨
                num:this.state.num+1,
                userid:'aaa', //새로운 상태값 추가
                xyz:'ABC'
            }
        );
    }//end handleClick
  
    render() {
        return (
            <div>
                <h2>{this.state.userid}</h2>
                <h2>{this.state.num}</h2>
                <h2>{this.state.xyz}</h2>
                <button onClick={this.handleClick}>Ok</button>               
            </div>
        );
    }
}

