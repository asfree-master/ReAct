import React, { Component } from 'react';
import {Concat} from "./component/Concat";
import {ConcatList} from "./component/ConcatList";
class App extends Component {
  render() {
    return (
      <div>
        <Concat/>
        <ConcatList/>
      </div>
    );
  }
}
export default App;