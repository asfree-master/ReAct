import React, { Component } from 'react';

export class Concat extends Component {
    render() {
        return (
            <div>
                <h1>Concats 홈페이지 </h1>
            </div>
        );
    }
}
