import React, { Component } from 'react';
export class ConcatList extends Component {
    render() {
        return (
            <div>
                <ul>
                    <li>홈페이지</li>
                    <li>이순신</li>
                    <li>유관순</li>
                    <li>강감찬</li>
                </ul>
            </div>
        );
    }
}

